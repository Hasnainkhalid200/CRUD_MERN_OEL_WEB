import './App.css';
import React, {useEffect} from "react"
import Axios  from 'axios';

function App() {

  const [foodName,setFoodName]= React.useState("");
  const [days,setDays]=React.useState(0);
  const [foodList,setFoodList]=React.useState([]);
  const [newFoodName,setNewFoodName]= React.useState("");
  
  useEffect(()=>{
    Axios.get("http://localhost:3001/read").then(response =>{
      setFoodList(response.data);
    })
  })


  const addTolist=()=>{
    Axios.post('http://localhost:3001/insert',{foodName:foodName,days:days})
  }

  const updateFood=(id)=>{
    Axios.put("http://localhost:3001/update",{id:id,newFoodName:newFoodName})
  }

  const deleteFood=(id)=>{
    Axios.delete(`http://localhost:3001/delete/${id}`)
  }
  return (
      <div className='App'>
       <i><h1>Internship Program</h1></i> 
        <i><label>Internee name: </label></i> 
        <input type="text" onChange={(event)=>{
          setFoodName(event.target.value);
        }} />
        <i><label>Salary: </label></i> 
        <input type="number" onChange={(event)=>{
          setDays(event.target.value);
        }}  />
        <button onClick={addTolist}>Submit Form</button>
        <hr/>
        {
          foodList.map((val, key)=>{
            return <div key={key}> 
             <i><h3>{val.foodName}</h3></i>
              <i><h3>{val.daysSinceIAte}</h3></i>
              <input type="text" placeholder='Enter Values'  onChange={(event)=>{
          setNewFoodName(event.target.value);
        }} />
              <button onClick={()=>updateFood(val._id)}>Add</button>
              <button onClick={()=>deleteFood(val._id)}>Remove</button>
            </div>
          })
        }
        </div>
    );
}

export default App;
